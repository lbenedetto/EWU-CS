class Tester {
	public static void main(String[] args) {
		Graph graph = Graph.loadDefaultGraph();
		graph.breadthFirstPrint(0);
	}
}
