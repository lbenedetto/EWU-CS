package Guitars;

public interface Guitar {
	void play();
}
