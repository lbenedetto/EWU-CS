package Guitars;

public class GibsonSG implements Guitar {
	@Override
	public void play() {
		System.out.println(" plays Gibson SG.");
	}
}
