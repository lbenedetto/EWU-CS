package Guitars;

public class FenderTelecaster implements Guitar {
	@Override
	public void play() {
		System.out.println(" plays Fender Telecaster.");
	}
}
