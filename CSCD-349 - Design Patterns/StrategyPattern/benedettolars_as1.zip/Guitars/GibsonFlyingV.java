package Guitars;

public class GibsonFlyingV implements Guitar {
	@Override
	public void play() {
		System.out.println(" plays Gibson Flying V.");
	}
}
