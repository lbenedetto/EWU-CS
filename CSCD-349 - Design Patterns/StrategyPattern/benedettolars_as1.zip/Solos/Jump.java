package Solos;

public class Jump implements Solo {
	@Override
	public void play() {
		System.out.println(" jumps off stage.");
	}
}
