package Solos;

public class Fire implements Solo {
	@Override
	public void play() {
		System.out.println(" sets guitar on fire.");
	}
}
