package Solos;

public class Smash implements Solo {
	@Override
	public void play() {
		System.out.println(" smashes guitar.");
	}
}
