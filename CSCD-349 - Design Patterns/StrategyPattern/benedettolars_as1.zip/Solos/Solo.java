package Solos;

public interface Solo {
	void play();
}
