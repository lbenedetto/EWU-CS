package actbs.managers;

interface IManager {

	void createLocation(String name);

	void createCompany(String name);
}
