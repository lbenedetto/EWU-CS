package actbs.system.trip.sections.berths;

public enum BerthClass {
	//The assignment description describes how many people can fit in each cabin type
	//But it doesn't matter because each cabin is only booked by one person
	F(), B(), E(), FA(), DF(), C(), DC()
}
