package actbs.system.trip.sections.berths;

public class Cabin extends Berth {
	public Cabin(int r, int c) {
		super(r, c);
	}
}
