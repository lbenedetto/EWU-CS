package actbs.system.location;

public class Seaport extends Location {
	public Seaport(String name) {
		super(name);
	}
}
