package actbs.system.location;

public class Airport extends Location {

	public Airport(String name) {
		super(name);
	}
}
