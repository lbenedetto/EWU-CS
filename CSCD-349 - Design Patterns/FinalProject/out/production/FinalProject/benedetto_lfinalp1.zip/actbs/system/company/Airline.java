package actbs.system.company;

import actbs.system.Vehicle.Flight.*;
import actbs.system.location.Airport;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Airline extends Company {

	private final HashMap<String, Flight> flights;

	public Airline(String name) {
		super(name);
		flights = new HashMap<>();
	}

	public String toString() {
		String out = getName() + "[";
		if (flights.isEmpty()) {
			return out + "]";
		}
		for (Map.Entry e : flights.entrySet()) {
			Flight f = (Flight) e.getValue();
			out += f.toString() + ", ";
		}
		return out.substring(0, out.length() - 2) + "]";
	}

	public void bookSeat(String flightID, SeatClass s, int row, int col) {
		if (flights.containsKey(flightID)) {
			flights.get(flightID).bookSeat(s, row, col);
			return;
		}
		System.out.println("Cannot book seat on non-existent flight");
		return;
	}

	public void createSection(String flightID, int rows, int cols, SeatClass s) {
		if (flights.containsKey(flightID)) {
			flights.get(flightID).createSection(rows, cols, s);
			return;
		}
		System.out.println("Cannot create flight section in non-existent flight");
	}

	public void createFlight(Airport orig, Airport dest, Date date, String flightID) {
		if (isValidFlightID(flightID)) {
			flights.put(flightID, new Flight(orig, dest, date, flightID));
			return;
		}
		System.out.println("Could not create flight. Flight with id \"" + flightID + "\" already exists.");
		return;
	}

	public ArrayList<Flight> findAvailableFlights(String orig, String dest) {
		ArrayList<Flight> availableFlights = new ArrayList<>();
		for (Map.Entry e : flights.entrySet()) {
			Flight f = (Flight) e.getValue();
			if (f.getOrigin().getName().equals(orig) && f.getDestination().getName().equals(dest) && f.hasAvailableSeats()) {
				availableFlights.add(f);
			}
		}
		return availableFlights;
	}

	public boolean isValidFlightID(String id){
		return !flights.containsKey(id);
	}
}
