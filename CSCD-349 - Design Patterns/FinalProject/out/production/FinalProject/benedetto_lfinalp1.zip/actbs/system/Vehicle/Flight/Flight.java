package actbs.system.Vehicle.Flight;

import actbs.system.Vehicle.Vehicle;
import actbs.system.location.Airport;

import java.util.ArrayList;
import java.util.Date;

public class Flight extends Vehicle {
	private final ArrayList<FlightSection> sections;
	private final String flightID;

	public Flight(Airport origin, Airport destination, Date departureDate, String flightID) {
		super(origin, destination, departureDate);
		sections = new ArrayList<>();
		this.flightID = flightID;
	}

	public String toString() {
		String out = getFlightID() + "|" + getDepartureDateString() + "|" + getOrigin().getName() + "|" + getDestination().getName() + "[";
		if (sections.isEmpty()) {
			return out + "]";
		}
		for (FlightSection s : sections) {
			out += s.toString() + ", ";
		}
		return out.substring(0, out.length() - 2) + "]";
	}

	public void bookSeat(SeatClass s, int row, int col) {
		for (FlightSection fs : sections) {
			if (fs.matchesSeatClass(s)) {
				fs.bookSeat(row, col);
				return;
			}
		}
		System.out.println("Could not book seat, there were no available seats in the requested seat class on the requested flight");
		return;
	}

	public boolean hasAvailableSeats() {
		for (FlightSection fs : sections){
			if(!fs.hasAvailableSeats()){
				return false;
			}
		}
		return true;
	}
	public void createSection(int rows, int cols, SeatClass s) {
		if (rows > 100) {
			System.out.println("Rows must not be greater than 100");
			return;
		}
		if (cols > 10) {
			System.out.println("Columns must not be greater than 10");
			return;
		}
		for (FlightSection fs : sections) {
			if (fs.matchesSeatClass(s)) {
				System.out.println("Could not create flight section. Section of that type already exists on flight");
				return;
			}
		}
		sections.add(new FlightSection(rows, cols, s));
	}


	private String getFlightID() {
		return flightID;
	}


}
