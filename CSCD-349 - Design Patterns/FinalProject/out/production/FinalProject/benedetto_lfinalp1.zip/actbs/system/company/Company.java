package actbs.system.company;

abstract class Company {
	private final String name;
	Company(String name){
		this.name = name;
	}
	String getName() {
		return name;
	}
}
