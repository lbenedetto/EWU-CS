package actbs.system.Vehicle.Flight;

class FlightSection {
	private final Seat[][] seats;
	private final SeatClass seatClass;
	private final int seatPrice;

	FlightSection(int rows, int cols, SeatClass s) {
		seats = new Seat[rows][cols];
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				seats[i][j] = new Seat(i + 1, j + 1);
		seatClass = s;
		//TODO:Allow setting of price according to guidelines of assignment part 2
		seatPrice = 500;
	}

	boolean matchesSeatClass(SeatClass s) {
		return seatClass.equals(s);
	}

	void bookSeat(int row, int col) {
		seats[row - 1][col - 1].bookSeat();
	}

	public boolean hasAvailableSeats() {
		for (Seat[] row : seats)
			for (Seat seat : row)
				if (!seat.isBooked())
					return true;
		return false;
	}

	public String toString() {
		String out = "";
		switch (seatClass) {
			case first:
				out = "F:";
				break;
			case business:
				out = "B:";
				break;
			case economy:
				out = "E:";
				break;
		}
		out += seatPrice + ":" + seats.length + ":" + seats[0].length;
		return out;
	}
}
