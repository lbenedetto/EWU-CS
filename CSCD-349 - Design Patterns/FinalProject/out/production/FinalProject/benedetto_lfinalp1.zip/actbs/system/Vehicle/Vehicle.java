package actbs.system.Vehicle;


import actbs.system.location.*;

import java.util.Calendar;
import java.util.Date;

public abstract class Vehicle {
	private final Location origin;
	private final Location destination;
	private final Date departureDate;

	protected Vehicle(Location origin, Location destination, Date date) {
		this.origin = origin;
		this.destination = destination;
		departureDate = date;
	}

	public Location getOrigin() {
		return origin;
	}

	public Location getDestination() {
		return destination;
	}

	protected String getDepartureDateString() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(departureDate);
		return cal.get(Calendar.YEAR) + ", " + cal.get(Calendar.MONTH) + ", " + cal.get(Calendar.DATE) + ", 0, 0";
	}
}
