package actbs.system;

import actbs.system.Vehicle.Flight.*;
import actbs.system.company.*;
import actbs.system.location.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SystemManager {
	private final HashMap<String, Airport> airports;
	private final HashMap<String, Airline> airlines;

	public SystemManager() {
		airports = new HashMap<>();
		airlines = new HashMap<>();
	}

	public void createAirport(String name) {
		name = name.toUpperCase();
		if (name.length() != 3) {
			System.out.println("Could not create airport with name " + name + ". Airport name must be 3 characters.");
			return;
		} else if (name.matches("[^A-Z]")) {
			System.out.println("Could not create airport with name " + name + ". Airport name must contain only characters.");
			return;
		} else if (airports.containsKey(name)) {
			System.out.println("Could not create airport with name " + name + ". Airport with that name already exists.");
			return;
		}
		airports.put(name, new Airport(name));
	}

	public void createAirline(String name) {
		if (airlineNameIsValid(name)) {
			airlines.put(name, new Airline(name));
		}
	}

	public void createFlight(String airlineName, String orig, String dest, int year, int month, int day, String id) {
		Date date = valiDate(day, month, year);
		if (flightIsValid(airlineName, orig, dest, date, id)) {
			airlines.get(airlineName).createFlight(airports.get(orig), airports.get(dest), date, id);
		}
	}

	public void createSection(String airline, String flightID, int rows, int cols, SeatClass s) {
		if (airlines.containsKey(airline)) {
			airlines.get(airline).createSection(flightID, rows, cols, s);
			return;
		}
		System.out.println("Could not create section in non-existent airline");
	}

	public void findAvailableFlights(String orig, String dest) {
		ArrayList<Flight> availableFlights = new ArrayList<>();
		for (Map.Entry e : airlines.entrySet()) {
			Airline a = (Airline) e.getValue();
			availableFlights.addAll(a.findAvailableFlights(orig, dest));
		}
		for (Flight f : availableFlights) {
			System.out.println(f.toString());
		}
	}

	public void bookSeat(String airline, String flightID, SeatClass s, int row, int col) {
		col = col - 64;
		if (airlines.containsKey(airline)) {
			airlines.get(airline).bookSeat(flightID, s, row, col);
			return;
		}
		System.out.println("Could not book seat in non-existent airline");
	}

	public void displaySystemDetails() {
		String out = "[";
		if (airports.isEmpty()) {
			System.out.println("[]");
			return;
		}
		for (Map.Entry e : airports.entrySet()) {
			Airport a = (Airport) e.getValue();
			out += a.getName() + ", ";
		}
		out = out.substring(0, out.length() - 2) + "]{";
		if (airlines.isEmpty()) {
			System.out.println(out + "}");
			return;
		}
		for (Map.Entry e : airlines.entrySet()) {
			Airline a = (Airline) e.getValue();
			out += a.toString() + ", ";
		}
		out = out.substring(0, out.length() - 2) + "}";
		System.out.println(out);
	}


	private boolean airlineNameIsValid(String name) {
		if (name.length() > 5) {
			System.out.println("Could not create airline with name " + name + ". Airline name must be less than 6 characters.");
			return false;
		} else if (airlines.containsKey(name)) {
			System.out.println("Could not create airline with name " + name + ". Airline already exists.");
			return false;
		}
		return true;
	}

	private boolean flightIsValid(String airlineName, String orig, String dest, Date date, String id) {
		if (date == null) {
			System.out.println("Could not create flight. Date was invalid");
			return false;
		} else if (!airlines.containsKey(airlineName)) {
			System.out.println("Could not create flight. Airline \"" + airlineName + "\" does not exist.");
			return false;
		} else if (!airports.containsKey(orig)) {
			System.out.println("Could not create flight. Airport \"" + orig + "\" does not exist.");
			return false;
		} else if (!airports.containsKey(dest)) {
			System.out.println("Could not create flight. Airport \"" + dest + "\" does not exist.");
			return false;
		} else if (!airlines.get(airlineName).isValidFlightID(id)) {
			System.out.println("Could not create flight. Flight \"" + id + "\" already exists in airline \"" + airlineName + "\"");
		}
		return true;
	}

	private Date valiDate(int day, int month, int year) {
		String dateStr = day + "-" + month + "-" + year;
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(dateStr);
		} catch (ParseException e) {
			return null;
		}
	}
}
