package actbs.system.Vehicle.Flight;

public enum SeatClass {
	first, business, economy
}
