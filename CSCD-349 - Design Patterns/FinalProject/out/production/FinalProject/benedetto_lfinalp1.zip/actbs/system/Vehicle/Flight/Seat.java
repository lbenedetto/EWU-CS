package actbs.system.Vehicle.Flight;

class Seat {
	private final String ID;
	private boolean booked;

	Seat(int row, int col) {
		String[] letters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J"};
		booked = false;
		ID = row + letters[col - 1];
	}

	boolean isBooked() {
		return booked;
	}

	private void setBooked() {
		this.booked = true;
	}

	void bookSeat() {
		if (isBooked()) {
			System.out.println("Could not book seat. Seat is already booked");
			return;
		}
		setBooked();
	}

	public String getID() {
		return ID;
	}
}
