Alex Toenniessen: ajt110195@gmail.com
Lars Benedetto: larsbenedetto@gmail.com
Richard Philips: mersennetwizter@gmail.com