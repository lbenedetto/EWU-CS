public class Tester {
	public static void main(String[] args) {
		Graph g = Graph.loadDefaultGraph();
		g.MSTPrint();
	}
}
