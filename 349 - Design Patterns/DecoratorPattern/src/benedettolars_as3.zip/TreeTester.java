import treePackage.tree.*;
import treePackage.decoration.*;

public class TreeTester {
	public static void main(String[] args) {
		Tree myTree = new ColoradoBlueSpruce();
		myTree = Star.getStar(myTree);
		myTree = new Ruffles(myTree);
		myTree = Star.getStar(myTree);
		myTree = new Ruffles(myTree);
		printTree(myTree);
	}

	private static void printTree(Tree tree) {
		System.out.println(tree.getDescription() + " costs $" + String.format("%.2f", tree.getCost()));
	}
}
