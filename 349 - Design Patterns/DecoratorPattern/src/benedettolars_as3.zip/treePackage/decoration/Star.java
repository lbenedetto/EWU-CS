package treePackage.decoration;


import treePackage.tree.Tree;

public class Star extends TreeDecoration {
	private Tree tree;

	private Star(Tree tree) {
		this.tree = tree;
	}

	public static Tree getStar(Tree tree) {
		if (!tree.getDescription().contains("Star"))
			return new Star(tree);
		System.out.println("Tree already has a star!");
		return tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", a Star";
	}

	@Override
	public double getCost() {
		return 4 + tree.getCost();
	}
}
