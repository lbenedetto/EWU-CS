package treePackage.decoration;


import treePackage.tree.Tree;

public class Ribbons extends TreeDecoration {
	private Tree tree;

	public Ribbons(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", Ribbons";
	}

	@Override
	public double getCost() {
		return 2 + tree.getCost();
	}
}
