package treePackage.decoration;

import treePackage.tree.Tree;

abstract class TreeDecoration extends Tree {
	public abstract String getDescription();
}
