package treePackage.decoration;


import treePackage.tree.Tree;

public class Lights extends TreeDecoration {
	private Tree tree;

	public Lights(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", Lights";
	}

	@Override
	public double getCost() {
		return 5 + tree.getCost();
	}
}
