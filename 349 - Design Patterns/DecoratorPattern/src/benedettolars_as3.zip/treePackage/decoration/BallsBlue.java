package treePackage.decoration;


import treePackage.tree.Tree;

public class BallsBlue extends TreeDecoration {
	private Tree tree;

	public BallsBlue(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", Blue Balls";
	}

	@Override
	public double getCost() {
		return 2 + tree.getCost();
	}
}
