package treePackage.decoration;


import treePackage.tree.Tree;

public class LEDs extends TreeDecoration {
	private Tree tree;

	public LEDs(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", LED's";
	}

	@Override
	public double getCost() {
		return 10 + tree.getCost();
	}
}
