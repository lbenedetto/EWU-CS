package treePackage.decoration;


import treePackage.tree.Tree;

public class BallsRed extends TreeDecoration {
	private Tree tree;

	public BallsRed(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", Red Balls";
	}

	@Override
	public double getCost() {
		return 1 + tree.getCost();
	}
}
