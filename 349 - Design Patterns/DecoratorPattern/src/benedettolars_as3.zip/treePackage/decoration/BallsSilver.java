package treePackage.decoration;


import treePackage.tree.Tree;

public class BallsSilver extends TreeDecoration {
	private Tree tree;

	public BallsSilver(Tree tree) {
		this.tree = tree;
	}

	@Override
	public String getDescription() {
		return tree.getDescription() + ", Silver Balls";
	}

	@Override
	public double getCost() {
		return 3 + tree.getCost();
	}
}
