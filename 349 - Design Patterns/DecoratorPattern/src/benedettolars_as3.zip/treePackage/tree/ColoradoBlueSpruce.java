package treePackage.tree;

public class ColoradoBlueSpruce extends Tree {
	public ColoradoBlueSpruce() {
		super("Colorado Blue Spruce");
	}

	@Override
	public double getCost() {
		return 50;
	}
}
