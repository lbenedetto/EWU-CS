package treePackage.tree;

public class FraserFir extends Tree {
	public FraserFir() {
		super("Fraser Fir");
	}

	@Override
	public double getCost() {
		return 35;
	}
}
