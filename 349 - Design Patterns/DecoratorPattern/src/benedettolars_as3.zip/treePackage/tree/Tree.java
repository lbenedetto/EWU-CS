package treePackage.tree;


public abstract class Tree {
	private String description;

	Tree(String type) {
		description = type + " tree decorated with";
	}

	public Tree() {

	}

	public String getDescription() {
		return description;
	}

	public abstract double getCost();
}
