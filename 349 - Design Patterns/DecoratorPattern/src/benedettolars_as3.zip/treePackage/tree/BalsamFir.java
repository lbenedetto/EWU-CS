package treePackage.tree;

public class BalsamFir extends Tree {
	public BalsamFir() {
		super("Balsam Fir");
	}

	@Override
	public double getCost() {
		return 25;
	}
}
