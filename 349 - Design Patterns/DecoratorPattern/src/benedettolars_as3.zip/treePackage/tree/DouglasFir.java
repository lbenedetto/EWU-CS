package treePackage.tree;

public class DouglasFir extends Tree {
	public DouglasFir() {
		super("Douglas Fir");
	}

	@Override
	public double getCost() {
		return 30;
	}
}
