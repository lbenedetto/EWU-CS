package shape;
public class NoSuchShapeException extends Exception {
	public NoSuchShapeException(String message) {
		super(message);
	}
}