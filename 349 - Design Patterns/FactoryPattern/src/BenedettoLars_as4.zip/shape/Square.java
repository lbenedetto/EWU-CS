package shape;

class Square extends Rectangle  implements Comparable{
	Square(double sidelength){
		super("Square", sidelength, sidelength);
	}
}
